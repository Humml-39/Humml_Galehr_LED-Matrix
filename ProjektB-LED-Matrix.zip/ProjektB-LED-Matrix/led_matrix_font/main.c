/*
 * led_matrix_font.c
 *
 * Created: 13.12.2020 11:40:54
 * Author : johih
 */ 

#include <avr/io.h>
#define F_CPU 12000000UL
#include <util/delay.h>
#include "8x8_matrix_font.h"

int main(void) //Testprogramm
{
	
	multiMatrix_init(0x00,1,4);
	while (1)
	{
		
		multiwrite2Matrix(' ',1);
		multiwrite2Matrix('~',2);
		multiwrite2Matrix('4',3);
		multiwrite2Matrix(' ',4);
		_delay_ms(1000);
		multiwrite2Matrix('B',1);
		multiwrite2Matrix('H',2);
		multiwrite2Matrix('e',3);
		multiwrite2Matrix('l',4);
		_delay_ms(1000);
		multidraw2Matrix(	0b00111100, //Similey
							0b01000010,
							0b10100101,
							0b10000001,
							0b10100101,
							0b10011001,
							0b01000010,
							0b00111100,1);
		multiwrite2Matrix('!',2);
		multiwrite2Matrix('?',3);
		multiwrite2Matrix('$',4);
		_delay_ms(1000);
		Matrix_intensity(0x07,4);
	}
}

